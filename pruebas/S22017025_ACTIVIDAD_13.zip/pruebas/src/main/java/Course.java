public class Course {


    public static int division(int numberOne, int numberTwo) {
        int result = numberOne / numberTwo;
        return result;
    }
}
