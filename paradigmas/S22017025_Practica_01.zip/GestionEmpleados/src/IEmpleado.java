public interface IEmpleado {
    double calcularIncentivo();
}
