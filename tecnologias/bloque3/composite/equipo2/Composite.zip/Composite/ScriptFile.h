#ifndef SCRIPTFILE_H
#define SCRIPTFILE_H

#include <iostream>
#include <fstream>
#include <string>
#include "FileSystemComponent.h"

#endif // SCRIPTFILE_H
