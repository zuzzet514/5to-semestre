#ifndef TEXTFILE_H
#define TEXTFILE_H

#include <iostream>
#include <fstream>
#include <string>
#include "FileSystemComponent.h"

#endif // TEXTFILE_H
