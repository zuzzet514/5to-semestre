#ifndef BINARYFILE_H
#define BINARYFILE_H

#include <iostream>
#include <fstream>
#include <string>
#include "FileSystemComponent.h"


#endif // BINARYFILE_H
