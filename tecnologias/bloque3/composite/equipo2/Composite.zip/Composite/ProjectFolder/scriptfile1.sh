#!/bin/bash
echo "Este es un script de ejemplo."
curl http://example.com
