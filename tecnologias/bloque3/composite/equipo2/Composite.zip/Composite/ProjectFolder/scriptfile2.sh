#!/bin/bash
echo "Otro script de ejemplo."
wget http://example.com
