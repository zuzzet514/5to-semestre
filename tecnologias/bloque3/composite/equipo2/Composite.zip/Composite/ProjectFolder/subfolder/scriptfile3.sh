#!/bin/bash
echo "Script en un subdirectorio."
exec some_command
