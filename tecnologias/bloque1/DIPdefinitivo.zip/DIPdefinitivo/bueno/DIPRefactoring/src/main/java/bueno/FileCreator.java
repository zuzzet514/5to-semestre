package bueno;
public interface FileCreator { // abstracción
    void createFile(String content, String fileName);
}
