package bueno;
public interface InputReader { // abstracción
    String readInput(String message);
}
